package com.bsc.qa.facets.reader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.bsc.facets.bor_file_generator_ui.pojo.ErrorReport;
import com.bsc.facets.bor_file_generator_ui.pojo.SubscriberDetail;
import com.github.ffpojo.file.writer.FileSystemFlatFileWriter;
import com.github.ffpojo.file.writer.FlatFileWriter;

public class UploadUtility {

	public List<SubscriberDetail> readExcelClaimDetails(String inputFilePath) throws Exception  {

		List<SubscriberDetail> claimDetails = new ArrayList<SubscriberDetail>();
		File inputFile = new File(inputFilePath);

		

			Workbook workbook = null;
		
			try {
				workbook = WorkbookFactory.create(inputFile);
			} catch (Exception e) {
				throw new Exception("File already open by some other application, Please close the file and retry to Upload!");
			}
			
			Sheet subscriberDetailSheet = workbook.getSheetAt(0);

			for (int i = 1; i <= subscriberDetailSheet.getLastRowNum(); i++) {
				Row row = subscriberDetailSheet.getRow(i);
				String subscriberId = getCellValue(row.getCell(0));
				String adjustmentType = getCellValue(row.getCell(1));
				SubscriberDetail cd = new SubscriberDetail(subscriberId, adjustmentType);
				claimDetails.add(cd);
				
			}

		return claimDetails;

	}
	
	public void writeComments(List<ErrorReport> errorList) throws FileNotFoundException, IOException{
			File outputFolder = new File(new File("").getAbsolutePath()+"//output//");	
			if(!outputFolder.exists()){
				outputFolder.mkdir();
			}
			File errorReport = new File(outputFolder.getAbsolutePath()+"/Error Report.txt");
			
	        FlatFileWriter writer = new FileSystemFlatFileWriter(errorReport,true);
	        writer.writeRecordList(errorList);
	        writer.close();
		
	}

	private static String getCellValue(Cell cell) {
		String celldata = "";
		try {
			switch (cell.getCellTypeEnum()) {
			case STRING:
				celldata = cell.getRichStringCellValue().getString().trim();
				break;
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					celldata = cell.getDateCellValue().toString();
				} else {
					BigDecimal bigDecimal = BigDecimal.valueOf(
							cell.getNumericCellValue()).stripTrailingZeros();
					celldata = bigDecimal.toPlainString().trim();
				}
				break;
			default:
				celldata = "";

			}
		} catch (Exception e) {
			// logger1.error("Error occured while reading a cell in excel!");
			// e.printStackTrace();
		}

		return celldata;

	}
}
