package com.bsc.facets.bor_file_generator_ui.pojo;

public class AdjustmentClaimsForm {
	
	private String clclId;
	private String adjustmentMode;
	private String checkDate;
	private String revenueAmount;
	private String netAmount;
	
	
	
	public AdjustmentClaimsForm(String clclId, String adjustmentMode, String checkDate, String revenueAmount,
			String netAmount) {
		super();
		this.clclId = clclId;
		this.adjustmentMode = adjustmentMode;
		this.checkDate = checkDate;
		this.revenueAmount = revenueAmount;
		this.netAmount = netAmount;
	}
	public String getClclId() {
		return clclId;
	}
	public void setClclId(String clclId) {
		this.clclId = clclId;
	}
	public String getAdjustmentMode() {
		return adjustmentMode;
	}
	public void setAdjustmentMode(String adjustmentMode) {
		this.adjustmentMode = adjustmentMode;
	}
	public String getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}
	public String getRevenueAmount() {
		return revenueAmount;
	}
	public void setRevenueAmount(String revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	public String getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}
	
	

}
