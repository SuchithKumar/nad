package com.bsc.facets.model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import com.bsc.facets.bor_file_generator_ui.pojo.PaidClaimsForm;

public class PaidClaimModel extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<PaidClaimsForm> paidClaims;

	String[] columns = new String[] { "SBSB ID", "MEM SFX", "SVC DT", "Check DT", "Rev AMT", "Net AMT", "Prov ID" };

	@Override
	public String getColumnName(int column) {
		return columns[column];
	}

	public void setPadiClaims(List<PaidClaimsForm> paidClaims) {
		this.paidClaims = paidClaims;
	}

	@Override
	public int getRowCount() {
		return paidClaims.size();
	}

	@Override
	public int getColumnCount() {
		return 7;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		PaidClaimsForm paidClaim = paidClaims.get(rowIndex);
		switch (columnIndex) {
		case 0:
			return paidClaim.getSbsbId();
		case 1:
			return paidClaim.getMemberSuffix();
		case 2:
			return paidClaim.getServiceDate();
		case 3:
			return paidClaim.getCheckDate();
		case 4:
			return paidClaim.getRevenueAmount();
		case 5:
			return paidClaim.getNetAmount();
		case 6:
			return paidClaim.getProviderId();
		default:
			return null;
		}

	}

}
