package com.bsc.facets.model;

import java.util.ArrayList;
import java.util.List;

import com.bsc.facets.bor_file_generator_ui.pojo.AdjustmentClaimsForm;

public class AdjustmentDatabase {
	
	private ArrayList<AdjustmentClaimsForm> adjustmentClaims;
	
	public AdjustmentDatabase() {
		adjustmentClaims = new ArrayList<AdjustmentClaimsForm>();
	}
	
	public void addClaim(AdjustmentClaimsForm claim) {
		adjustmentClaims.add(claim);
	}
	
	public List<AdjustmentClaimsForm> getClaims() {
		return adjustmentClaims;
	}
}
