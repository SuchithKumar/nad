package com.bsc.facets.bor_file_generator_ui;

import java.awt.Color;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.UIManager;
import javax.swing.SwingConstants;

public class Progress {
	static JProgressBar bar;
	static JFrame pro;
	static JLabel lblTestReportCreation;
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void progressbar(String message){
		UIManager.put("ProgressBar.selectionBackground", Color.green);
		UIManager.put("ProgressBar.selectionForeground", Color.blue);
		bar= new JProgressBar();
		bar.setOpaque(true);
		bar.setIndeterminate(true);
		bar.setBorderPainted(false);
		
		pro=new JFrame();
		pro.setResizable(false);
		bar.setEnabled(true);
		lblTestReportCreation = new JLabel();
		lblTestReportCreation.setHorizontalAlignment(SwingConstants.CENTER);
		lblTestReportCreation.setText(message);
		GroupLayout groupLayout = new GroupLayout(pro.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(41)
							.addComponent(bar, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(55)
							.addComponent(lblTestReportCreation, GroupLayout.PREFERRED_SIZE, 274, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(43, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(bar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblTestReportCreation, GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
					.addContainerGap())
		);
		pro.getContentPane().setLayout(groupLayout);
		pro.toFront();
		pro.setLocation(300, 300);
		pro.setVisible(true);
		pro.pack();
	}
	
	public static void close(){
		pro.setVisible(true);
		pro.dispose();
	}
	
	public static void updateValue(int value){
		bar.setValue(value);
		pro.repaint();
	}
}
