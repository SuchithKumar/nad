package com.bsc.facets.bor_file_generator_ui.pojo;

public class SubscriberDetail {

	private String subscriberId;
	private String adjustmentType;
	
	
	
	public SubscriberDetail(String subscriberId, String adjustmentType) {
		super();
		this.subscriberId = subscriberId;
		this.adjustmentType = adjustmentType;
	}
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getAdjustmentType() {
		return adjustmentType;
	}
	public void setAdjustmentType(String adjustmentType) {
		this.adjustmentType = adjustmentType;
	}
	
	
	
}
