package com.bsc.facets.model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import com.bsc.facets.bor_file_generator_ui.pojo.AdjustmentClaimsForm;

public class AdjustmentClaimModel extends AbstractTableModel {

	private List<AdjustmentClaimsForm> adjustmentClaims;
	/**
	 * 
	 */
	String[] columns = new String[] { "Claim ID", "Adjustment Mode", "Check Date", "Net Amount", "Revenue Amount" };
	private static final long serialVersionUID = 1L;

	public void setAdjustmentClaims(List<AdjustmentClaimsForm> adjustmentClaims) {
		this.adjustmentClaims = adjustmentClaims;
	}

	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return columns[column];
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return adjustmentClaims.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		AdjustmentClaimsForm adjustmentClaim = adjustmentClaims.get(rowIndex);

		switch (columnIndex) {
		case 0:
			return adjustmentClaim.getClclId();
		case 1:
			return adjustmentClaim.getAdjustmentMode();
		case 2:
			return adjustmentClaim.getCheckDate();
		case 3:
			return adjustmentClaim.getRevenueAmount();
		case 4:
			return adjustmentClaim.getNetAmount();
		default:
			return null;
		}
	}

}
