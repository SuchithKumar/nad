package com.bsc.facets.bor_file_generator_ui.pojo;

public class PaidClaimsForm {
	
	private String sbsbId;
	private String serviceDate;
	private String checkDate;
	private String providerId;
	private String revenueAmount;
	private String netAmount;
	private String memberSuffix;
	
	
	
	public PaidClaimsForm(String sbsbId, String serviceDate, String checkDate, String providerId, String revenueAmount,
			String netAmount, String memberSuffix) {
		super();
		this.sbsbId = sbsbId;
		this.serviceDate = serviceDate;
		this.checkDate = checkDate;
		this.providerId = providerId;
		this.revenueAmount = revenueAmount;
		this.netAmount = netAmount;
		this.memberSuffix = memberSuffix;
	}
	
	
	public String getSbsbId() {
		return sbsbId;
	}
	public void setSbsbId(String sbsbId) {
		this.sbsbId = sbsbId;
	}
	public String getServiceDate() {
		return serviceDate;
	}
	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}
	public String getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public String getRevenueAmount() {
		return revenueAmount;
	}
	public void setRevenueAmount(String revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	public String getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}
	public String getMemberSuffix() {
		return memberSuffix;
	}
	public void setMemberSuffix(String memberSuffix) {
		this.memberSuffix = memberSuffix;
	}

	
	
}
