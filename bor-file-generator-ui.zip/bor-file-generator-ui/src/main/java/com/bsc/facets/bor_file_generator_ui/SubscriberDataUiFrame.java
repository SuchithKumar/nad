package com.bsc.facets.bor_file_generator_ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;
import javax.swing.text.AbstractDocument;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import com.bsc.facets.bor_file_generator_ui.pojo.AdjustmentClaimsForm;
import com.bsc.facets.bor_file_generator_ui.pojo.DefaultHeaderRenderer;
import com.bsc.facets.bor_file_generator_ui.pojo.PaidClaimsForm;
import com.bsc.facets.controller.Controller;
import com.bsc.facets.model.AdjustmentClaimModel;
import com.bsc.facets.model.PaidClaimModel;
import com.bsc.facets.util.DateLabelFormatter;
import com.bsc.facets.util.MemSFXFieldFilter;
import com.bsc.facets.util.SbsbFieldFilter;
import com.bsc.facets.util.AmountFieldFilter;
import com.bsc.facets.util.ClclIdFieldFilter;

public class SubscriberDataUiFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTable paidClaimsTable;
	private JTable adjustmentClaimsTable;
	private JButton btnAddPaid;
	private JButton btnAddAdjs;
	private JTextField sbsbPaidTextField;
	private JTextField revenueAmtPaidTextField;
	private JTextField netAmtPaidTextField;
	private JTextField memSfxPaidTextField;
	private JTextField clmIdAdjsTextField;
	private JTextField revenueAmtAdjsTextField;
	private JTextField netAmtAdjsTextField;
	private JComboBox<String> providerIdComboBox;
	private JComboBox<String> bulkUploadComboBox;
	private JComboBox<String> adjustmentModeComboBox;

	private JDatePickerImpl serviceDatePicker;
	private JDatePickerImpl checkPaidDatePicker;
	private JDatePickerImpl checkAdjsDatePicker;

	private Controller controller = new Controller();
	
	private AdjustmentClaimModel adjustmentTableModel=new AdjustmentClaimModel();
	private PaidClaimModel paidTableModel = new PaidClaimModel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SubscriberDataUiFrame frame = new SubscriberDataUiFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws URISyntaxException 
	 */
	public SubscriberDataUiFrame() throws URISyntaxException {
		
		
		
		setTitle("Argus BOR File Utility");
		setResizable(false);
		
		Properties p = new Properties();
		p.put("text.today", "Today");
		p.put("text.month", "Month");
		p.put("text.year", "Year");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1010, 780);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Tahoma", Font.BOLD, 11));
		setJMenuBar(menuBar);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmHelpDocumentation = new JMenuItem("Help Documentation");
		mnHelp.add(mntmHelpDocumentation);
		mntmHelpDocumentation.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					File file = new File("");
					Desktop.getDesktop().open(new File(file.getAbsolutePath()+"/Help.docx"));
				} catch (IOException  e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
//		mntmHelpDocumentation.
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel titlePanel = new JPanel();
		titlePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		titlePanel.setBounds(10, 11, 976, 54);
		contentPane.add(titlePanel);
		titlePanel.setLayout(null);
		
		JLabel lblBorFileGenerator = new JLabel("Argus BOR file utility");
		lblBorFileGenerator.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBorFileGenerator.setBounds(399, 15, 221, 25);
		titlePanel.add(lblBorFileGenerator);
		
		JPanel adjustmentClaimsPanel = new JPanel();
		adjustmentClaimsPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		adjustmentClaimsPanel.setBounds(10, 383, 302, 246);
		contentPane.add(adjustmentClaimsPanel);
		adjustmentClaimsPanel.setLayout(null);
		
		JLabel lblAdjustmentClaimsForm = new JLabel("Adjustment Claims Form");
		lblAdjustmentClaimsForm.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAdjustmentClaimsForm.setBounds(80, 9, 155, 15);
		adjustmentClaimsPanel.add(lblAdjustmentClaimsForm);
		
		btnAddAdjs = new JButton("ADD");
		btnAddAdjs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String clclId = clmIdAdjsTextField.getText().trim();
				 String adjustmentMode = String.valueOf(adjustmentModeComboBox.getSelectedItem()).trim();
				 Date checkDateDate = (Date) checkAdjsDatePicker.getModel().getValue();
				 SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
				 String checkDate = sdf.format(checkDateDate).toUpperCase().trim();
				 String revenueAmount = revenueAmtAdjsTextField.getText().trim();
				 String netAmount=netAmtAdjsTextField.getText().trim();
				 
				 AdjustmentClaimsForm adjustmentClaimForm = new AdjustmentClaimsForm(clclId, adjustmentMode, checkDate, revenueAmount, netAmount);
				 controller.addAdjustmentClaim(adjustmentClaimForm);
				 adjustmentTableModel.fireTableDataChanged();
				 clearAdjustmentFormStatus();
				 
			}
		});
		btnAddAdjs.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAddAdjs.setBounds(108, 212, 89, 23);
		adjustmentClaimsPanel.add(btnAddAdjs);
		
		JScrollPane adjsFormScrollPane = new JScrollPane();
		adjsFormScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		adjsFormScrollPane.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		adjsFormScrollPane.setBounds(10, 28, 282, 179);
		adjsFormScrollPane.setPreferredSize(new Dimension(282, 129));
		adjustmentClaimsPanel.add(adjsFormScrollPane);
		
		JPanel adjustmentClaimsFormPanel = new JPanel();
		adjustmentClaimsFormPanel.setPreferredSize(new Dimension(282, 200));
		adjustmentClaimsFormPanel.setLayout(null);
		
		JLabel label = new JLabel("Claim ID");
		label.setFont(new Font("Tahoma", Font.BOLD, 11));
		label.setBounds(25, 13, 105, 14);
		adjustmentClaimsFormPanel.add(label);
		
		clmIdAdjsTextField = new JTextField();
		clmIdAdjsTextField.setBackground(new Color(255, 255, 255));
		clmIdAdjsTextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		clmIdAdjsTextField.setEditable(false);
		clmIdAdjsTextField.setColumns(10);
		clmIdAdjsTextField.setBounds(140, 11, 86, 20);
		
		((AbstractDocument)clmIdAdjsTextField.getDocument()).setDocumentFilter(
                new ClclIdFieldFilter());
		
		adjustmentClaimsFormPanel.add(clmIdAdjsTextField);
		clmIdAdjsTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,adjustmentClaimsFormPanel);
            }
        });
		
		JLabel label_1 = new JLabel("Check Date");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_1.setBounds(25, 77, 105, 17);
		adjustmentClaimsFormPanel.add(label_1);
		
		UtilDateModel checkDateAdjModel = new UtilDateModel();
		JDatePanelImpl checkAdjDatePanel = new JDatePanelImpl(checkDateAdjModel, p);
		checkAdjsDatePicker = new JDatePickerImpl(checkAdjDatePanel, new DateLabelFormatter());
		checkAdjsDatePicker.getJFormattedTextField().setBounds(new Rectangle(0, 0, 86, 20));
		checkAdjsDatePicker.getJFormattedTextField().setBackground(new Color(255, 255, 255));
		checkAdjsDatePicker.setSize(124, 20);
		checkAdjsDatePicker.setLocation(139, 74);
		checkAdjsDatePicker.setEnabled(false);
		checkAdjsDatePicker.getJFormattedTextField().setFont(new Font("Tahoma", Font.BOLD, 11));
		checkAdjsDatePicker.setFont(new Font("Tahoma", Font.BOLD, 11));
		checkAdjsDatePicker.getComponent(1).setEnabled(false);
		adjustmentClaimsFormPanel.add(checkAdjsDatePicker);
		
		JLabel label_2 = new JLabel("Revenue Amount");
		label_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_2.setBounds(25, 108, 105, 14);
		adjustmentClaimsFormPanel.add(label_2);
		
		revenueAmtAdjsTextField = new JTextField();
		revenueAmtAdjsTextField.setBackground(new Color(255, 255, 255));
		revenueAmtAdjsTextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		revenueAmtAdjsTextField.setEditable(false);
		revenueAmtAdjsTextField.setColumns(10);
		revenueAmtAdjsTextField.setBounds(140, 105, 86, 20);
		
		((AbstractDocument)revenueAmtAdjsTextField.getDocument()).setDocumentFilter(
                new AmountFieldFilter());
		
		adjustmentClaimsFormPanel.add(revenueAmtAdjsTextField);
		revenueAmtAdjsTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,adjustmentClaimsFormPanel);
            }
        });
		
		JLabel label_12 = new JLabel("Net Amount");
		label_12.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_12.setBounds(25, 139, 105, 14);
		adjustmentClaimsFormPanel.add(label_12);
		
		netAmtAdjsTextField = new JTextField();
		netAmtAdjsTextField.setBackground(new Color(255, 255, 255));
		netAmtAdjsTextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		netAmtAdjsTextField.setEditable(false);
		netAmtAdjsTextField.setColumns(10);
		netAmtAdjsTextField.setBounds(140, 136, 86, 20);
		
		((AbstractDocument)netAmtAdjsTextField.getDocument()).setDocumentFilter(
                new AmountFieldFilter());
		
		adjustmentClaimsFormPanel.add(netAmtAdjsTextField);
		netAmtAdjsTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,adjustmentClaimsFormPanel);
            }
        });
		
		adjsFormScrollPane.setViewportView(adjustmentClaimsFormPanel);
		
		JLabel lblAdjustmentMode = new JLabel("Adjustment mode");
		lblAdjustmentMode.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAdjustmentMode.setBounds(24, 44, 106, 14);
		adjustmentClaimsFormPanel.add(lblAdjustmentMode);
		
		adjustmentModeComboBox = new JComboBox<String>();
		adjustmentModeComboBox.setBackground(new Color(255, 255, 255));
		adjustmentModeComboBox.setFont(new Font("Tahoma", Font.BOLD, 11));
		adjustmentModeComboBox.setModel(new DefaultComboBoxModel(new String[] {"Select", "Adjustment", "Reversal"}));
		adjustmentModeComboBox.setBounds(140, 41, 86, 20);
		adjustmentClaimsFormPanel.add(adjustmentModeComboBox);
		adjustmentModeComboBox.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,adjustmentClaimsFormPanel);
            }
        });
		
		JPanel generatePanel = new JPanel();
		generatePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		generatePanel.setBounds(10, 640, 976, 45);
		contentPane.add(generatePanel);
		generatePanel.setLayout(null);
		
		JButton btnGenerate = new JButton("GENERATE");
		btnGenerate.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnGenerate.setBounds(579, 10, 129, 23);
		generatePanel.add(btnGenerate);
		
		JLabel lblClickTheGenerate = new JLabel("Click the generate button to generate the BOR File");
		lblClickTheGenerate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblClickTheGenerate.setBounds(266, 12, 293, 18);
		generatePanel.add(lblClickTheGenerate);
		
		JPanel paidClaimsTablePanel = new JPanel();
		paidClaimsTablePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		paidClaimsTablePanel.setBounds(327, 146, 659, 218);
		contentPane.add(paidClaimsTablePanel);
		paidClaimsTablePanel.setLayout(null);
		
		JScrollPane paidClaimsScrollPane = new JScrollPane();
		paidClaimsScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		paidClaimsScrollPane.setFont(new Font("Tahoma", Font.BOLD, 11));
		paidClaimsScrollPane.setViewportBorder(new LineBorder(new Color(0, 0, 0)));
		paidClaimsScrollPane.setBounds(10, 11, 639, 193);
		paidClaimsTablePanel.add(paidClaimsScrollPane);
		
		paidClaimsTable = new JTable();
		paidClaimsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		paidClaimsTable.setEnabled(false);
		paidClaimsTable.setSurrendersFocusOnKeystroke(true);
		paidClaimsTable.setFont(new Font("Tahoma", Font.BOLD, 10));
		paidClaimsTable.setSurrendersFocusOnKeystroke(true);
		paidTableModel.setPadiClaims(controller.getPaidClaimsData());
		paidClaimsTable.setModel(paidTableModel);
		paidClaimsTable.setBackground(SystemColor.control);
		paidClaimsTable.getTableHeader().setDefaultRenderer(new DefaultHeaderRenderer());
//		resizeColumnWidth(paidClaimsTable);
		paidClaimsScrollPane.setViewportView(paidClaimsTable);
		
		JPanel bulkDataPanel = new JPanel();
		bulkDataPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		bulkDataPanel.setBounds(10, 73, 976, 36);
		contentPane.add(bulkDataPanel);
		bulkDataPanel.setLayout(null);
		
		JLabel lblDoYouWant = new JLabel("Do you want to upload bulk data?");
		lblDoYouWant.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDoYouWant.setBounds(334, 9, 261, 19);
		bulkDataPanel.add(lblDoYouWant);
		
		bulkUploadComboBox = new JComboBox<String>();
		bulkUploadComboBox.setFont(new Font("Tahoma", Font.BOLD, 11));
		bulkUploadComboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Select", "YES", "NO"}));
		bulkUploadComboBox.setBounds(599, 9, 60, 20);
		bulkDataPanel.add(bulkUploadComboBox);
		
		JButton btnUploadBulkClaims = new JButton("UPLOAD");
		btnUploadBulkClaims.setAlignmentX(Component.CENTER_ALIGNMENT);
		btnUploadBulkClaims.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnUploadBulkClaims.setBounds(677, 9, 93, 20);
		bulkDataPanel.add(btnUploadBulkClaims);
		
		JPanel paidClaimsPanel = new JPanel();
		paidClaimsPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		paidClaimsPanel.setBounds(10, 115, 302, 250);
		contentPane.add(paidClaimsPanel);
		paidClaimsPanel.setLayout(null);
		
		btnAddPaid = new JButton("ADD");
		btnAddPaid.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String sbsbId = sbsbPaidTextField.getText();
				Date serviceDateDate = (Date) serviceDatePicker.getModel().getValue();
				Date checkDateDate = (Date) checkPaidDatePicker.getModel().getValue();
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
				String serviceDate = sdf.format(serviceDateDate).toUpperCase().trim();
				String checkDate = sdf.format(checkDateDate).toUpperCase().trim();
				String providerId =String.valueOf(providerIdComboBox.getSelectedItem()).trim();
				String revenueAmount = revenueAmtPaidTextField.getText();
				String netAmount = netAmtPaidTextField.getText();
				String memberSuffix = memSfxPaidTextField.getText();

				PaidClaimsForm paidForm = new PaidClaimsForm(sbsbId, serviceDate, checkDate, providerId, revenueAmount, netAmount, memberSuffix);
				controller.addPaidClaim(paidForm);
				paidTableModel.fireTableDataChanged();
				clearPaidFormStatus();
				
			}

			private void validateAddedPaidForm() {
				// TODO Auto-generated method stub
				
			}
		});
		btnAddPaid.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAddPaid.setBounds(108, 223, 89, 23);
		paidClaimsPanel.add(btnAddPaid);
		
		JLabel lblPaidClaimsForm = new JLabel("Paid Claims Form");
		lblPaidClaimsForm.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPaidClaimsForm.setBounds(98, 9, 111, 14);
		paidClaimsPanel.add(lblPaidClaimsForm);
		
		JScrollPane paidFormScrollPane = new JScrollPane();
		paidFormScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		paidFormScrollPane.setBounds(10, 29, 282, 190);
		
		paidClaimsPanel.add(paidFormScrollPane);
		
		JPanel paidClaimsFormPanel = new JPanel();
		paidClaimsFormPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		paidClaimsFormPanel.setPreferredSize(new Dimension(259, 280));
		paidClaimsFormPanel.setLayout(null);
		
		
		
		
		JLabel label_4 = new JLabel("Subscriber ID");
		label_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_4.setBounds(24, 6, 105, 14);
		paidClaimsFormPanel.add(label_4);
		
		sbsbPaidTextField = new JTextField();
		sbsbPaidTextField.setBackground(new Color(255, 255, 255));
		sbsbPaidTextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		sbsbPaidTextField.setEditable(false);
		sbsbPaidTextField.setColumns(10);
		sbsbPaidTextField.setBounds(139, 5, 86, 20);
		
		((AbstractDocument)sbsbPaidTextField.getDocument()).setDocumentFilter(
                new SbsbFieldFilter());
		
		paidClaimsFormPanel.add(sbsbPaidTextField);
		sbsbPaidTextField.addFocusListener(new java.awt.event.FocusAdapter() {
	            public void focusGained(java.awt.event.FocusEvent evt) {
	                jTextFieldFocusGained(evt,paidClaimsFormPanel);
	            }
	        });
		
		JLabel lblServiceDate = new JLabel("Service Date");
		lblServiceDate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblServiceDate.setBounds(24, 68, 105, 17);
		paidClaimsFormPanel.add(lblServiceDate);
		
		UtilDateModel serviceStartDateModel = new UtilDateModel();
		JDatePanelImpl serviceStartDatePanel = new JDatePanelImpl(serviceStartDateModel, p);
		serviceDatePicker = new JDatePickerImpl(serviceStartDatePanel, new DateLabelFormatter());
		serviceDatePicker.getJFormattedTextField().setBackground(new Color(255, 255, 255));
		serviceDatePicker.setSize(124, 20);
		serviceDatePicker.setLocation(139, 66);
		serviceDatePicker.setEnabled(false);
		serviceDatePicker.getComponent(1).setEnabled(false);
		serviceDatePicker.getJFormattedTextField().setFont(new Font("Tahoma", Font.BOLD, 11));
		paidClaimsFormPanel.add(serviceDatePicker);
		serviceDatePicker.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,paidClaimsFormPanel);
            }
        });
		
		UtilDateModel serviceEndDateModel = new UtilDateModel();
		JDatePanelImpl serviceEndDatePanel = new JDatePanelImpl(serviceEndDateModel, p);;
		
		JLabel label_7 = new JLabel("Check Date");
		label_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_7.setBounds(24, 99, 105, 17);
		paidClaimsFormPanel.add(label_7);
		
		UtilDateModel checkDatePaidModel = new UtilDateModel();
		JDatePanelImpl checkPaidDatePanel = new JDatePanelImpl(checkDatePaidModel, p);
		checkPaidDatePicker = new JDatePickerImpl(checkPaidDatePanel, new DateLabelFormatter());
		checkPaidDatePicker.getJFormattedTextField().setBackground(new Color(255, 255, 255));
		checkPaidDatePicker.setSize(124, 20);
		checkPaidDatePicker.setLocation(139, 95);
		checkPaidDatePicker.setEnabled(false);
		checkPaidDatePicker.getComponent(1).setEnabled(false);
		checkPaidDatePicker.getJFormattedTextField().setFont(new Font("Tahoma", Font.BOLD, 11));
		checkPaidDatePicker.setFont(new Font("Tahoma", Font.BOLD, 11));
		paidClaimsFormPanel.add(checkPaidDatePicker);
		checkPaidDatePicker.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,paidClaimsFormPanel);
            }
        });
		
		JLabel label_8 = new JLabel("Revenue Amount");
		label_8.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_8.setBounds(24, 130, 105, 14);
		paidClaimsFormPanel.add(label_8);
		
		revenueAmtPaidTextField = new JTextField();
		revenueAmtPaidTextField.setBackground(new Color(255, 255, 255));
		revenueAmtPaidTextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		revenueAmtPaidTextField.setEditable(false);
		revenueAmtPaidTextField.setColumns(10);
		revenueAmtPaidTextField.setBounds(139, 128, 86, 20);
		
		((AbstractDocument)revenueAmtPaidTextField.getDocument()).setDocumentFilter(
                new AmountFieldFilter());
		
		paidClaimsFormPanel.add(revenueAmtPaidTextField);
		revenueAmtPaidTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,paidClaimsFormPanel);
            }
        });
		
		JLabel label_9 = new JLabel("Net Amount");
		label_9.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_9.setBounds(24, 161, 105, 14);
		paidClaimsFormPanel.add(label_9);
		
		netAmtPaidTextField = new JTextField();
		netAmtPaidTextField.setBackground(new Color(255, 255, 255));
		netAmtPaidTextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		netAmtPaidTextField.setEditable(false);
		netAmtPaidTextField.setColumns(10);
		netAmtPaidTextField.setBounds(139, 159, 86, 20);
		
		((AbstractDocument)netAmtPaidTextField.getDocument()).setDocumentFilter(
                new AmountFieldFilter());
		
		paidClaimsFormPanel.add(netAmtPaidTextField);
		netAmtPaidTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,paidClaimsFormPanel);
            }
        });
		
		JLabel label_10 = new JLabel("Provider ID");
		label_10.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_10.setBounds(24, 192, 105, 14);
		paidClaimsFormPanel.add(label_10);
		
		
		providerIdComboBox = new JComboBox<String>();
		providerIdComboBox.setBackground(new Color(255, 255, 255));
		providerIdComboBox.setFont(new Font("Tahoma", Font.BOLD, 8));
		providerIdComboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"EXPO PHARMACY",
				"SAN MIGUEL PHARMACY", "KIM AN PHARMACY", "TIANGUIS PHARMACY",
				"GLEN ECHO PHARMACY", "CVS CAREMARK ADVANCE",
				"CVS/SPECIALTY 02921", "BAYLOR UNIVERSITY HE",
				"NEW VISTA PHARMACY", "VIRGINIA MASON BUCK",
				"NORTH LITTLE ROCK VA", "ALLIANCERX WALGREENS", "MALVIN YAN",
				"KATHLEEN HERMANSON"}));
		providerIdComboBox.setSelectedIndex(0);
		providerIdComboBox.setBounds(140, 191, 110, 20);
		paidClaimsFormPanel.add(providerIdComboBox);
		providerIdComboBox.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,paidClaimsFormPanel);
            }
        });
		
		
		JLabel label_11 = new JLabel("Member Suffix");
		label_11.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_11.setBounds(24, 37, 105, 14);
		paidClaimsFormPanel.add(label_11);
		
		memSfxPaidTextField = new JTextField();
		memSfxPaidTextField.setBackground(new Color(255, 255, 255));
		memSfxPaidTextField.setFont(new Font("Tahoma", Font.BOLD, 10));
		memSfxPaidTextField.setEditable(false);
		memSfxPaidTextField.setColumns(10);
		memSfxPaidTextField.setBounds(139, 35, 86, 20);
		
		((AbstractDocument)memSfxPaidTextField.getDocument()).setDocumentFilter(
                new MemSFXFieldFilter());
		
		paidClaimsFormPanel.add(memSfxPaidTextField);
		memSfxPaidTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFocusGained(evt,paidClaimsFormPanel);
            }
        });
		
		paidFormScrollPane.setViewportView(paidClaimsFormPanel);
		
		JPanel adjustmentClaimsTablePanel = new JPanel();
		adjustmentClaimsTablePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		adjustmentClaimsTablePanel.setBounds(329, 414, 659, 215);
		contentPane.add(adjustmentClaimsTablePanel);
		adjustmentClaimsTablePanel.setLayout(null);
		
		JScrollPane adjustmentTableScrollPane = new JScrollPane();
		adjustmentTableScrollPane.setBounds(10, 11, 639, 193);
		adjustmentClaimsTablePanel.add(adjustmentTableScrollPane);
		
		adjustmentClaimsTable = new JTable();
		adjustmentClaimsTable.setEnabled(false);
		adjustmentClaimsTable.setFont(new Font("Tahoma", Font.BOLD, 10));
//		adjustmentClaimsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		
		adjustmentTableModel.setAdjustmentClaims(controller.getAdjustmentClaimsData());
		adjustmentClaimsTable.setModel(adjustmentTableModel);
		adjustmentClaimsTable.setBackground(SystemColor.control);
		adjustmentClaimsTable.getTableHeader().setDefaultRenderer(new DefaultHeaderRenderer());
		adjustmentClaimsTable.setSurrendersFocusOnKeystroke(true);
//		resizeColumnWidth(adjustmentClaimsTable);
		adjustmentTableScrollPane.setViewportView(adjustmentClaimsTable);
		
		JPanel paidClaimsTitlePanel = new JPanel();
		paidClaimsTitlePanel.setForeground(Color.WHITE);
		paidClaimsTitlePanel.setBackground(Color.DARK_GRAY);
		paidClaimsTitlePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		paidClaimsTitlePanel.setBounds(327, 115, 659, 27);
		contentPane.add(paidClaimsTitlePanel);
		
		JLabel lblNewLabel = new JLabel("Entered Paid Claim Data Table");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		paidClaimsTitlePanel.add(lblNewLabel);
		
		JPanel adjsTypeTitlePanel = new JPanel();
		adjsTypeTitlePanel.setBackground(Color.DARK_GRAY);
		adjsTypeTitlePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		adjsTypeTitlePanel.setBounds(328, 383, 659, 27);
		contentPane.add(adjsTypeTitlePanel);
		
		JLabel lblNewLabel_1 = new JLabel("Entered Adjustment Claim Data Table");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		adjsTypeTitlePanel.add(lblNewLabel_1);
		
		JLabel copyrightsLabel = new JLabel("© 2019 Mphasis The Next Applied. All rights reserved");
		copyrightsLabel.setFont(new Font("Tahoma", Font.BOLD, 9));
		copyrightsLabel.setBounds(356, 697, 282, 14);
		contentPane.add(copyrightsLabel);
		
		btnUploadBulkClaims.setVisible(false);
		setPaidFormStatus(false);
		setAdjustmentFormStatus(false);
		btnGenerate.setEnabled(false);
		
		bulkUploadComboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				switch(String.valueOf(bulkUploadComboBox.getSelectedItem())){
					
					case "Select" : {
						setPaidFormStatus(false);
						setAdjustmentFormStatus(false);
						btnUploadBulkClaims.setVisible(false);
						btnGenerate.setEnabled(false);
						break;
					}
						
					case "YES" : {
						btnUploadBulkClaims.setVisible(true);
						setAdjustmentFormStatus(false);
						setPaidFormStatus(false);
						break;
					}
					
					case "NO" : {
						btnUploadBulkClaims.setVisible(false);
						setAdjustmentFormStatus(true);
						setPaidFormStatus(true);
						break;
					}
					
					default : {
						break;
					}
				}
			}
		});
		
	}
	
	
	public void setPaidFormStatus(boolean ability){
		sbsbPaidTextField.setEditable(ability);
		serviceDatePicker.setEnabled(ability);
		serviceDatePicker.getComponent(1).setEnabled(ability);
		checkPaidDatePicker.setEnabled(ability);
		checkPaidDatePicker.getComponent(1).setEnabled(ability);
		revenueAmtPaidTextField.setEditable(ability);
		netAmtPaidTextField.setEditable(ability);
		providerIdComboBox.setEnabled(ability);
		memSfxPaidTextField.setEditable(ability);
		btnAddPaid.setEnabled(ability);
		
		
	}

	public void clearPaidFormStatus(){
		sbsbPaidTextField.setText("");		
		serviceDatePicker.getJFormattedTextField().setText("");
		checkPaidDatePicker.getJFormattedTextField().setText("");
		checkPaidDatePicker.getJFormattedTextField().setText("");
		revenueAmtPaidTextField.setText("");
		netAmtPaidTextField.setText("");
		providerIdComboBox.setSelectedIndex(0);
		memSfxPaidTextField.setText("");
	}
	
	public void setAdjustmentFormStatus(boolean ability){
		clmIdAdjsTextField.setEditable(ability);
		adjustmentModeComboBox.setEnabled(ability);
		checkAdjsDatePicker.setEnabled(ability);
		checkAdjsDatePicker.getComponent(1).setEnabled(ability);
		revenueAmtAdjsTextField.setEditable(ability);
		netAmtAdjsTextField.setEditable(ability);
		btnAddAdjs.setEnabled(ability);
	}
	
	public void clearAdjustmentFormStatus(){
		clmIdAdjsTextField.setText("");
		adjustmentModeComboBox.setSelectedIndex(0);
		checkAdjsDatePicker.getJFormattedTextField().setText("");;
		revenueAmtAdjsTextField.setText("");
		netAmtAdjsTextField.setText("");
	}
	
	
	 private void jTextFieldFocusGained(java.awt.event.FocusEvent evt, JPanel panel) {
	        java.awt.Component focusedComponent = evt.getComponent();
	        panel.scrollRectToVisible(focusedComponent.getBounds(null));
	        repaint();
	    }
}
