package com.bsc.facets.bor_file_generator_ui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.bsc.facets.bor_file_generator_ui.dao.HibernateUtil;
import com.bsc.facets.bor_file_generator_ui.pojo.Connection;



public class LoginFrame extends JFrame {

	private JPanel contentPane;
	private static Connection conn = new Connection();

	public static Connection getConn() {
		return conn;
	}

	public static void setConn(Connection conn) {
		LoginFrame.conn = conn;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 342);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(20, 72, 340, 190);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("DB Environment");
		label.setFont(new Font("Tahoma", Font.BOLD, 11));
		label.setBounds(10, 51, 97, 14);
		panel.add(label);
		
		final JComboBox environmentComboBox = new JComboBox(new DefaultComboBoxModel(new String[] {"Select", "FACN51A", "FACH71A", "FACH70A", "FACN52A", "FACN90A", "FACH72A", "FACN31A", "FACN32A", "FACH63A", "FACH64A"}));
		environmentComboBox.setSelectedIndex(2);
		environmentComboBox.setFont(new Font("Tahoma", Font.BOLD, 11));
		environmentComboBox.setBounds(107, 48, 133, 20);
		panel.add(environmentComboBox);
		
		JLabel label_1 = new JLabel("Username");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_1.setBounds(10, 82, 73, 14);
		panel.add(label_1);
		
		username = new JTextField();
		username.setText("syskumar33");
		username.setFont(new Font("Tahoma", Font.BOLD, 11));
		username.setColumns(10);
		username.setBounds(107, 79, 133, 20);
		panel.add(username);
		
		JLabel label_2 = new JLabel("[ Ex : syLanId ]");
		label_2.setForeground(new Color(220, 20, 60));
		label_2.setFont(new Font("Tahoma", Font.ITALIC, 11));
		label_2.setBounds(251, 82, 79, 14);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Password");
		label_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_3.setBounds(10, 113, 72, 14);
		panel.add(label_3);
		
		password = new JPasswordField();
		password.setText("H71#FacetsDB");
		password.setBounds(107, 110, 133, 20);
		panel.add(password);
		
		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String user = (String) username.getText();
				String pass = (String) password.getText();
				String selection = (String) environmentComboBox.getSelectedItem();
				SubscriberDataUiFrame subscriberUiFrame;
				if (selection == "FACN51A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACN51A");
					conn.setFacetsServer("UORC398N.DEV.BSCAL.LOCAL");
					conn.setUrl("jdbc:oracle:thin:@UORC398N.DEV.BSCAL.LOCAL:12521:FACN51A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
							
						} 
					} catch (Exception e1) {

						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACH71A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACH71A");
					conn.setFacetsServer("uorc392h.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc392h.dev.bscal.local:12521:FACH71A");

					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}

				} else if (selection == "FACN52A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACN52A");
					conn.setFacetsServer("uorc372n.DEV.BSCAL.LOCAL");
					conn.setUrl("jdbc:oracle:thin:@uorc372n.DEV.BSCAL.LOCAL:12521:FACN52A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();

						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACH70A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACH70A");
					conn.setFacetsServer("uorc395h.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc395h.dev.bscal.local:12521:FACH70A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACN90A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACN90A");
					conn.setFacetsServer("fach90-scan.bsc.bscal.com");
					conn.setUrl("jdbc:oracle:thin:@fach90-scan.bsc.bscal.com:12521:FACN90A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACH72A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACH72A");
					conn.setFacetsServer("uorc134h.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc134h.dev.bscal.local:12521:FACH72A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						} 
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACN31A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACN31A");
					conn.setFacetsServer("uorc398n.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc398n.dev.bscal.local:12521:FACN31A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						} 
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACN32A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACN32A");
					conn.setFacetsServer("uorc372n.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc372n.dev.bscal.local:12521:FACN32A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						} 
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACH63A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACH63A");
					conn.setFacetsServer("uorc392h.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc392h.dev.bscal.local:12521:FACH63A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				} else if (selection == "FACH64A") {
					conn.setUsername(user);
					conn.setPassword(pass);
					conn.setFacetsDB("FACH64A");
					conn.setFacetsServer("uorc395h.dev.bscal.local");
					conn.setUrl("jdbc:oracle:thin:@uorc395h.dev.bscal.local:12521:FACH64A");
					try {
						if (HibernateUtil.testConnection(conn) == true) {
							JOptionPane.showMessageDialog(null, "Successfully connected to DB!");
							subscriberUiFrame = new SubscriberDataUiFrame();
							subscriberUiFrame.setVisible(true);
							App.loginFrame.setVisible(false);
						} 
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid credentials!");
					}
				}

			
			}
		});
		loginButton.setForeground(Color.BLACK);
		loginButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		loginButton.setBorder(UIManager.getBorder("Button.border"));
		loginButton.setBounds(128, 141, 89, 23);
		panel.add(loginButton);
		
		JLabel lblUserLogin = new JLabel("User Login");
		lblUserLogin.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblUserLogin.setBounds(132, 11, 73, 26);
		panel.add(lblUserLogin);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(20, 11, 340, 50);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label_4 = new JLabel("SA Return File Generator");
		label_4.setBounds(68, 16, 213, 23);
		label_4.setFont(new Font("Arial", Font.BOLD, 17));
		panel_1.add(label_4);
		
		JLabel label_5 = new JLabel("© 2019 Mphasis The Next Applied. All rights reserved");
		label_5.setFont(new Font("Tahoma", Font.BOLD, 9));
		label_5.setBounds(56, 278, 282, 14);
		contentPane.add(label_5);
		
		success = new JTextField();
		success.setColumns(10);
	}
	
	public static Connection getConnection() {
		return conn;
	}
	
	private JTextField success;
	private JTextField username;
	private JPasswordField password;
}
