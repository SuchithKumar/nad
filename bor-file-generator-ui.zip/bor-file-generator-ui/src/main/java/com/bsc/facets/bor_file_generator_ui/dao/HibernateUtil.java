package com.bsc.facets.bor_file_generator_ui.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.bsc.facets.bor_file_generator_ui.LoginFrame;
import com.bsc.facets.bor_file_generator_ui.pojo.Connection;

public class HibernateUtil {
	
	
	public static SessionFactory createSessionFactory(){
		Connection conn = LoginFrame.getConnection();
		Configuration configuration = new Configuration().configure("resources/hibernate.cfg.xml"); // Exporting as Jar
//		Configuration configuration = new Configuration().configure(); // Eclipse working
		configuration.getProperties().setProperty("hibernate.connection.username", conn.getUsername());
		configuration.getProperties().setProperty("hibernate.connection.password", conn.getPassword());
		configuration.getProperties().setProperty("hibernate.connection.url", conn.getUrl());
		ServiceRegistry serviceRegistry =  new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory factory = configuration.buildSessionFactory(serviceRegistry);
		return factory;
	}

	public static SessionFactory createSessionFactory(Connection conn){
//		Connection conn = LoginFrame.getConnection();
		Configuration configuration = new Configuration().configure(); // Exporting as Jar
//		Configuration configuration = new Configuration().configure(); // Eclipse working
		configuration.getProperties().setProperty("hibernate.connection.username", conn.getUsername());
		configuration.getProperties().setProperty("hibernate.connection.password", conn.getPassword());
		configuration.getProperties().setProperty("hibernate.connection.url", conn.getUrl());
		ServiceRegistry serviceRegistry =  new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory factory = configuration.buildSessionFactory(serviceRegistry);
		return factory;
	}
	
	public static boolean testConnection(Connection conn){
		boolean success = false;
		Configuration configuration = new Configuration().configure("resources/hibernate.cfg.xml");
		configuration.getProperties().setProperty("hibernate.connection.username", conn.getUsername());
		configuration.getProperties().setProperty("hibernate.connection.password", conn.getPassword());
		configuration.getProperties().setProperty("hibernate.connection.url", conn.getUrl());
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		SessionFactory factory = configuration.buildSessionFactory(serviceRegistry);
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		success = session.isConnected();
		txn.commit();
		session.close();
		return success;
	}
	
}
