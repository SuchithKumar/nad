package com.bsc.facets.model;

import java.util.ArrayList;
import java.util.List;

import com.bsc.facets.bor_file_generator_ui.pojo.PaidClaimsForm;

public class PaidDatabase {
	
	private ArrayList<PaidClaimsForm> paidClaims;
	
	public PaidDatabase() {
		paidClaims = new ArrayList<PaidClaimsForm>();
	}
	
	public void addClaim(PaidClaimsForm claims) {
		paidClaims.add(claims);
	}
	
	public List<PaidClaimsForm> getClaims() {
		return paidClaims;
	}
}
