package com.bsc.facets.bor_file_generator_ui;


/**
 * Hello world!
 *
 */
public class App 
{
	public static LoginFrame loginFrame=new LoginFrame();
    public static void main( String[] args ){
    	loginFrame.setVisible(true);
    }
}

