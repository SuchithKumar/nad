package com.bsc.facets.controller;

import java.util.List;

import com.bsc.facets.bor_file_generator_ui.pojo.AdjustmentClaimsForm;
import com.bsc.facets.bor_file_generator_ui.pojo.PaidClaimsForm;
import com.bsc.facets.dao.DatabaseUtil;
import com.bsc.facets.model.AdjustmentDatabase;
import com.bsc.facets.model.PaidDatabase;

public class Controller {
	
	PaidDatabase paidClaimsDB = new PaidDatabase();
	AdjustmentDatabase adjustmentClaimsDB = new AdjustmentDatabase();
	
	DatabaseUtil databaseUtil = new DatabaseUtil();
	
	public List<PaidClaimsForm> getPaidClaimsData() {
		return paidClaimsDB.getClaims();
	}

	public List<AdjustmentClaimsForm> getAdjustmentClaimsData(){
		return adjustmentClaimsDB.getClaims();
	}
	
	public int addPaidClaim(PaidClaimsForm paidClaim) {
		if(databaseUtil.checkDataPresent(paidClaim)==true) {
			paidClaimsDB.addClaim(paidClaim);
			System.out.println("Data present for subscriber");
			return 0;
		}
		System.out.println("Data not present for subscriber");
		return 1;
	}
	
	public int addAdjustmentClaim(AdjustmentClaimsForm adjustmentClaim) {
		System.out.println("its till here");
		adjustmentClaimsDB.addClaim(adjustmentClaim);
		return 0;
	}
	
}
