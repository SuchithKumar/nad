package com.bsc.facets.bor_file_generator_ui.pojo;

public class Connection {

	String username;
	String password;
	String facetsDB;
	String facetsServer;
	String url;
	
	
	public String getFacetsDB() {
		return facetsDB;
	}
	public void setFacetsDB(String facetsDB) {
		this.facetsDB = facetsDB;
	}
	public String getFacetsServer() {
		return facetsServer;
	}
	public void setFacetsServer(String facetsServer) {
		this.facetsServer = facetsServer;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	@Override
	public String toString() {
		return "Connection [username=" + username + ", password=" + password + ", facetsDB=" + facetsDB
				+ ", facetsServer=" + facetsServer + ", url=" + url + "]";
	}
	
	
	
	
}
