package com.bsc.facets.bor_file_generator_ui.pojo;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class ErrorReport {

	String claimId;
	String clmlengthErr;
	String clmLevelErr;
	String adjTTypeErr;
	String clmDbErr;
	String duplicateErr;
	
	@PositionalField(initialPosition=1,finalPosition=14)
	public String getClaimId() {
		return claimId;
	}
	
	@PositionalField(initialPosition=16,finalPosition=46)
	public String getClmlengthErr() {
		return clmlengthErr;
	}
	
	@PositionalField(initialPosition=48,finalPosition=78)
	public String getClmLevelErr() {
		return clmLevelErr;
	}
	
	@PositionalField(initialPosition=80,finalPosition=108)
	public String getAdjTTypeErr() {
		return adjTTypeErr;
	}
	
	@PositionalField(initialPosition=110,finalPosition=130)
	public String getClmDbErr() {
		return clmDbErr;
	}
	
	@PositionalField(initialPosition=132,finalPosition=150)
	public String getDuplicateErr() {
		return duplicateErr;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	public void setClmlengthErr(String clmlengthErr) {
		this.clmlengthErr = clmlengthErr;
	}
	public void setClmLevelErr(String clmLevelErr) {
		this.clmLevelErr = clmLevelErr;
	}
	public void setAdjTTypeErr(String adjTTypeErr) {
		this.adjTTypeErr = adjTTypeErr;
	}
	public void setClmDbErr(String clmDbErr) {
		this.clmDbErr = clmDbErr;
	}
	public void setDuplicateErr(String duplicateErr) {
		this.duplicateErr = duplicateErr;
	}
	
	
	
}
