import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class App {
	
	public static void main(String[] args) {
		FileReader reader = new FileReader();
		try {
			
			reader.getUniqueItems();
			
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
